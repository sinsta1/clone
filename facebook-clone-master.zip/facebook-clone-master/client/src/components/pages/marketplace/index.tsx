import React from 'react';

const MarketplacePage: React.FC = () => {
  return <div>marketplace</div>;
};

export default MarketplacePage;
