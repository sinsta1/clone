import React from 'react';

const GamingPage = () => {
  return <div>gaming page</div>;
};

export default GamingPage;
