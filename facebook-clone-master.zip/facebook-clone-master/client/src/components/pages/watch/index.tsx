import React from 'react';

const WatchPage: React.FC = () => {
  return <div>Watch</div>;
};

export default WatchPage;
